
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import xgboost as xgb
import shap
import os
import tensorflow as tf
from tensorflow.keras.layers import Dense, LeakyReLU
from sklearn.model_selection import train_test_split
import streamlit as st

# 设置Matplotlib使用英文字体
import matplotlib

matplotlib.rcParams['font.family'] = 'sans-serif'
matplotlib.rcParams['font.sans-serif'] = ['Arial']

# ================== 自定义样式 ==================
st.markdown("""
<style>
    /* 主容器样式 */
    .main {
        background-color: #f5f7fb;
        padding: 2rem;
    }

    /* 标题样式 */
    h1 {
        color: #2c3e50;
        font-family: 'Roboto', sans-serif;
        border-bottom: 3px solid #3498db;
        padding-bottom: 0.5rem;
    }

    /* 侧边栏样式 */
    [data-testid="stSidebar"] {
        background: linear-gradient(145deg, #2c3e50 0%, #3498db 100%);
        padding: 1.5rem;
        border-radius: 0 15px 15px 0;
    }

    /* 按钮样式 */
    .stButton>button {
        background: linear-gradient(45deg, #3498db, #2980b9);
        color: white;
        border-radius: 25px;
        padding: 0.5rem 2rem;
        transition: all 0.3s;
    }

    .stButton>button:hover {
        transform: scale(1.05);
        box-shadow: 0 4px 15px rgba(52,152,219,0.4);
    }

    /* 选项卡样式 */
    [data-baseweb="tab-list"] {
        background: #ffffff;
        border-radius: 10px;
        padding: 0.5rem;
    }

    /* 输入框标签样式 */
    .stSlider label, .stSelectbox label {
        font-weight: 600!important;
        color: #2c3e50!important;
    }

    /* 成功提示样式 */
    .stSuccess {
        background: #e8f5e9!important;
        border-radius: 10px;
        padding: 1rem;
    }
</style>
""", unsafe_allow_html=True)

# ================== 引入外部字体 ==================
st.markdown("""
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
""", unsafe_allow_html=True)


# ================== SHAP Visualization Component ==================
def st_shap(plot, height=None):
    """Embed SHAP visualization in Streamlit"""
    try:
        if isinstance(plot, shap.plots._force.BaseVisualizer):
            # 处理力导向图
            shap_html = f"<head>{shap.getjs()}</head><body>{plot.html()}</body>"
            st.components.v1.html(shap_html, height=height)
        elif hasattr(plot, 'html'):
            # 处理其他SHAP原生HTML对象
            shap_html = f"<head>{shap.getjs()}</head><body>{plot.html()}</body>"
            st.components.v1.html(shap_html, height=height)
        else:
            # 处理matplotlib图形
            fig = plt.gcf()
            st.pyplot(fig)
            plt.close()
    except Exception as e:
        st.error(f"Visualization error: {str(e)}")


# ================== GAN Model Definition ==================
class GAN:
    def __init__(self, input_dim, output_dim):
        self.input_dim = input_dim
        self.output_dim = output_dim
        self.generator = self.build_generator()
        self.discriminator = self.build_discriminator()
        self.gan = self.build_gan()

    def build_generator(self):
        model = tf.keras.Sequential()
        model.add(Dense(128, input_dim=self.input_dim))
        model.add(LeakyReLU(alpha=0.2))
        model.add(Dense(256))
        model.add(LeakyReLU(alpha=0.2))
        model.add(Dense(self.output_dim, activation='tanh'))
        return model

    def build_discriminator(self):
        model = tf.keras.Sequential()
        model.add(Dense(256, input_dim=self.output_dim))
        model.add(LeakyReLU(alpha=0.2))
        model.add(Dense(128))
        model.add(LeakyReLU(alpha=0.2))
        model.add(Dense(1, activation='sigmoid'))
        model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])
        return model

    def build_gan(self):
        self.discriminator.trainable = False
        model = tf.keras.Sequential([self.generator, self.discriminator])
        model.compile(loss='binary_crossentropy', optimizer='adam')
        return model

    def train(self, X_train, epochs, batch_size):
        half_batch = batch_size // 2
        for epoch in range(epochs):
            idx = np.random.randint(0, X_train.shape[0], half_batch)
            real_data = X_train[idx]
            noise = np.random.normal(0, 1, (half_batch, self.input_dim))
            fake_data = self.generator.predict(noise)

            d_loss_real = self.discriminator.train_on_batch(real_data, np.ones((half_batch, 1)))
            d_loss_fake = self.discriminator.train_on_batch(fake_data, np.zeros((half_batch, 1)))
            d_loss = 0.5 * np.add(d_loss_real, d_loss_fake)

            noise = np.random.normal(0, 1, (batch_size, self.input_dim))
            g_loss = self.gan.train_on_batch(noise, np.ones((batch_size, 1)))

            # ================== Data Loading & Model Training ==================


def load_data():
    # 修改为相对路径
    current_dir = os.path.dirname(os.path.abspath(__file__))
    data_path = os.path.join(current_dir, "data", "11.25号数据.xlsx")
    data = pd.read_excel(data_path, engine='openpyxl')
    return data.iloc[:, :-3], data.iloc[:, -3:]


def train_model_and_shap(SYHFeatures, SYHLabels, target_id, num_samples):
    # GAN Data Augmentation
    gan = GAN(SYHFeatures.shape[1], SYHFeatures.shape[1])
    gan.train(SYHFeatures.values, epochs=1000, batch_size=64)

    # Generate synthetic data
    noise = np.random.normal(0, 1, (num_samples, SYHFeatures.shape[1]))
    generated_data = gan.generator.predict(noise)
    generated_labels = SYHLabels.values[np.random.choice(SYHLabels.shape[0], num_samples, replace=True)]

    # Combine datasets
    augmented_data = np.vstack([SYHFeatures.values, generated_data])
    augmented_labels = np.vstack([SYHLabels.values, generated_labels])

    # Split data
    X_train, X_test, y_train, y_test = train_test_split(
        augmented_data, augmented_labels[:, target_id], test_size=0.2, random_state=42)

    # Train model
    model = xgb.XGBRegressor(learning_rate=0.1, max_depth=5, n_estimators=100)
    model.fit(X_train, y_train)

    # Calculate SHAP values with feature names
    explainer = shap.Explainer(model, feature_names=SYHFeatures.columns.tolist())
    train_shap_values = explainer(X_train)
    test_shap_values = explainer(X_test)

    return model, explainer, train_shap_values, test_shap_values


# ================== Streamlit Main Interface ==================
def main():
    st.title("Prediction of Three-Phase Product Distribution in Sludge Pyrolysis")

    # Load data
    SYHFeatures, SYHLabels = load_data()

    # Sidebar controls
    with st.sidebar:
        st.header("Model Configuration")
        target_id = st.selectbox("Target Variable", options=[0, 1, 2],
                                 format_func=lambda x: ["Gas Yield", "Liquid Yield", "Solid Yield"][x])
        num_samples = st.selectbox("GAN Generated Samples", [200, 500, 1000, 2000, 5000])
        max_display = st.slider("Max Features Display", 5, 20, 10)

        if st.button("Start Training"):
            with st.spinner("Training in progress..."):
                try:
                    model, explainer, train_shap, test_shap = train_model_and_shap(
                        SYHFeatures, SYHLabels, target_id, num_samples)

                    st.session_state.update({
                        "model": model,
                        "explainer": explainer,
                        "train_shap": train_shap,
                        "test_shap": test_shap,
                        "features": SYHFeatures.columns.tolist(),
                        "ranges": {col: (float(SYHFeatures[col].min()), float(SYHFeatures[col].max()))
                                   for col in SYHFeatures.columns}
                    })
                    st.success("Training completed!")
                except Exception as e:
                    st.error(f"Training failed: {str(e)}")

    # Main interface
    if "model" in st.session_state:
        # Real-time prediction
        st.header("Real-time Prediction")
        inputs = {}
        cols = st.columns(3)
        for idx, col in enumerate(st.session_state["features"]):
            with cols[idx % 3]:
                f_min, f_max = st.session_state["ranges"][col]
                inputs[col] = st.slider(col, f_min, f_max, (f_min + f_max) / 2)

        input_df = pd.DataFrame([inputs])
        prediction = st.session_state.model.predict(input_df)[0]
        st.success(f"Prediction Result: {prediction:.2f}")

        # SHAP visualization
        st.header("Feature Impact Analysis")

        tab1, tab2, tab3, tab4, tab5 = st.tabs(
            ["Waterfall Plot", "Beeswarm Plot", "Decision Plot", "Dependence Plot", "Force Plot"])

        with tab1:
            st.subheader("Waterfall Plot")
            try:
                sample_idx = st.number_input("Sample Index for Waterfall Plot",
                                             min_value=0,
                                             max_value=len(st.session_state.test_shap) - 1,
                                             value=0)
                st_shap(shap.plots.waterfall(st.session_state.test_shap[sample_idx]))
            except Exception as e:
                st.error(f"Waterfall plot error: {str(e)}")

        with tab2:
            st.subheader("Beeswarm Plot")
            try:
                st_shap(shap.plots.beeswarm(st.session_state.train_shap, max_display=max_display))
            except Exception as e:
                st.error(f"Beeswarm plot error: {str(e)}")

        with tab3:
            st.subheader("Decision Plot")
            try:
                sample_idx = st.number_input("Sample Index for Decision Plot",
                                             min_value=0,
                                             max_value=len(st.session_state.test_shap) - 1,
                                             value=0)
                st_shap(shap.plots.decision(st.session_state.test_shap[sample_idx].base_values,
                                            st.session_state.test_shap[sample_idx].values,
                                            st.session_state.test_shap[sample_idx].data,
                                            feature_names=st.session_state["features"]))
            except Exception as e:
                st.error(f"Decision plot error: {str(e)}")

        with tab4:
            st.subheader("Dependence Plot")
            try:
                feature_name = st.selectbox("Select Feature for Dependence Plot",
                                            options=st.session_state["features"])
                st_shap(shap.plots.scatter(st.session_state.train_shap[:, feature_name]))
            except Exception as e:
                st.error(f"Dependence plot error: {str(e)}")

        with tab5:
            st.subheader("Force Plot")
            analysis_mode = st.radio("Select Analysis Mode:",
                                     ("Sample Analysis", "Custom Input"),
                                     horizontal=True)

            if analysis_mode == "Sample Analysis":
                try:
                    sample_idx = st.number_input("Sample Index for Force Plot",
                                                 min_value=0,
                                                 max_value=len(st.session_state.test_shap) - 1,
                                                 value=0)
                    force_plot = shap.plots.force(
                        base_value=st.session_state.test_shap[sample_idx].base_values,
                        shap_values=st.session_state.test_shap[sample_idx].values,
                        features=st.session_state.test_shap[sample_idx].data,
                        feature_names=st.session_state["features"],
                        matplotlib=False
                    )
                    st_shap(force_plot, height=400)
                except Exception as e:
                    st.error(f"Force plot error: {str(e)}")
            else:
                st.markdown("### Custom Feature Inputs")
                custom_inputs = {}

                cols = st.columns(3)
                for idx, feature in enumerate(st.session_state["features"]):
                    with cols[idx % 3]:
                        f_min, f_max = st.session_state["ranges"][feature]
                        custom_inputs[feature] = st.slider(
                            f"{feature} ({f_min:.1f}-{f_max:.1f})",
                            min_value=f_min,
                            max_value=f_max,
                            value=(f_min + f_max) / 2,
                            key=f"custom_{feature}"
                        )

                if st.button("Generate Custom Force Plot"):
                    try:
                        input_df = pd.DataFrame([custom_inputs])[st.session_state["features"]]
                        prediction = st.session_state.model.predict(input_df)[0]
                        explainer = st.session_state.explainer
                        shap_values = explainer(input_df)

                        st.markdown(f"**Prediction Result:** `{prediction:.2f}`")

                        force_plot = shap.plots.force(
                            base_value=shap_values.base_values[0],
                            shap_values=shap_values.values[0],
                            features=input_df.iloc[0].values,
                            feature_names=st.session_state["features"],
                            matplotlib=False
                        )
                        st_shap(force_plot, height=400)

                    except Exception as e:
                        st.error(f"Error generating custom plot: {str(e)}")


if __name__ == "__main__":
    main()
    input("Press Enter to exit...")